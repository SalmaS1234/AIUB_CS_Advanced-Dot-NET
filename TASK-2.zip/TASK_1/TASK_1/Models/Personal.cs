﻿using System;
namespace TASK_1.Models
{
	public class Personal
	{
        public string name;
        public string fname;
        public string mname;
        public string religion;
        public string nationality;
        public string age;
        public string presentAddress;
        public string parmanentAddress;
    }
}


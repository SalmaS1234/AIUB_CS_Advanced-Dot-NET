﻿using System;
namespace TASK_1.Models
{
	public class Reference
	{
        public string name;
        public string title;
        public string companyName;
        public string email;
        public string phone;
    }
}


﻿using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using TASK_1.Models;

namespace TASK_1.Controllers;


public class HomeController : Controller
{
    private readonly ILogger<HomeController> _logger;

    public HomeController(ILogger<HomeController> logger)
    {
        _logger = logger;
    }

    public IActionResult Index()
    {
        var i = new TASK_1.Models.Index();
        i.name = "MD. TOUKIR AHMED";
        i.id = "21-45214-2";
        i.email = "toukerahmed.2728@gmail.com";
        i.github = "https://github.com/TUHIN27289";
        i.profile = "https://github.com/TUHIN27289";
        ViewBag.i = new TASK_1.Models.Index[] { i };
        return View();
    }

    public IActionResult Privacy()
    {

        return View();
    }

    public IActionResult Education()
    {
        var e = new Education();
        e.degree = " BSC";
        e.year = "  2025";
        e.instution = "AIUB";
        ViewBag.e = new TASK_1.Models.Education[] { e };


        return View();
    }

    public IActionResult Project()
    {
        var pr = new Project();
        pr.courseName = "Computer Graphics";
        pr.title = "Interactive OpenGL Graphics Project";
        pr.description = "Interactive OpenGL Graphics Project, Createing immersive scenes with dynamic weather, day/night cycles, and user control. Explore the power of computer graphics through realistic simulations. This project showcases rendering, animation, and user interaction techniques.";

        return View();
    }

    public IActionResult Personal()
    {
        var p = new Personal();
        p.name = "MD.TOUKIR AHMED";
        p.fname = "MD.AZIZAR RAHMAN";
        p.mname = "MST SHORIFA YEASMIN";
        p.religion = "Islam";
        p.nationality = "Bangladeshi";
        p.age = "30";
        p.presentAddress = "khuril,kazibzri,kha-119";
        p.parmanentAddress = "Birampur,Dinajpur,Bangladesh\n";

        return View();
    }

    public IActionResult Reference()
    {
        var r = new Reference();
        r.name = "MD AZIZAR RAHMAN";
        r.title = "CEO Of ABC Software Limited";
        r.companyName = "ABC Software Limited";
        r.email = "toukerahmed.2728@gmail.com";
        r.phone = "0179095XXXX";
;        return View();
    }

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
}


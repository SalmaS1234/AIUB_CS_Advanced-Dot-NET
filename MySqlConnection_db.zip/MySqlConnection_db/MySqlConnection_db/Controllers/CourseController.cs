﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using MySqlConnection_db.Models;
using MySqlConnection_db.Controllers;
using System.Linq;
using System.Diagnostics;
using MySqlConnection_db.EF;
// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace MySqlConnection_db.Controllers
{
    public class CourseController : Controller
    {
        // GET: /<controller>/
        [HttpGet]
        public IActionResult Course()
        {
            return View(new Models.Course());
        }
        [HttpPost]
        public IActionResult Course(MySqlConnection_db.EF.Course ce)
        {
            var db = new UmsContext();
            db.Courses.Add(ce);
            db.SaveChanges();
            return RedirectToAction("ViewCourse");
        }

       
        public IActionResult ViewCourse()
        {
            var db = new UmsContext();
            var c = db.Courses.ToList();
            return View(c);
        }
    }
}


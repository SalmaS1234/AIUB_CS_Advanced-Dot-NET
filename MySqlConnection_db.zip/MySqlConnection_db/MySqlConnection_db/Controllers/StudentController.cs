﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using MySqlConnection_db.Models;
using MySqlConnection_db.Controllers;
using System.Linq;
using System.Diagnostics;
using MySqlConnection_db.EF;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace MySqlConnection_db.Controllers
{
    public class StudentController : Controller
    {
        // GET: /<controller>/
        [HttpGet]
        public IActionResult Student()
        {
            return View(new Models.Student());
        }
        //[HttpPost]
        //public IActionResult Student(EF.Student s)
        //{
        //    var db = new UmsContext();
        //    db.EF.Student.Add(s);
        //    db.SaveChanges();
        //    return RedirectToAction("ViewStudent");
        //}

        [HttpPost]
        public IActionResult Student(MySqlConnection_db.EF.Student s)
        {
            var db = new UmsContext();
            db.Students.Add(s);
            db.SaveChanges();
            return RedirectToAction("ViewStudent");
        }
        public IActionResult ViewStudent()
        {
            var db = new UmsContext();
            var ST = db.Students.ToList();
            return View(ST);
        }


    }
}


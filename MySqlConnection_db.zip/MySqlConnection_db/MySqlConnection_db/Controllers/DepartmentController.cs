﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using MySqlConnection_db.Models;
using MySqlConnection_db.Controllers;
using System.Linq;
using System.Diagnostics;
using MySqlConnection_db.EF;
// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace MySqlConnection_db.Controllers
{
    public class DepartmentController : Controller
    {
        // GET: /<controller>/
        [HttpGet]
        public IActionResult Department()
        {
            return View(new Models.Department());
        }

        [HttpPost]
        public IActionResult Department(EF.Department d)
        {
            var db = new UmsContext();
            db.Departments.Add(d);
            db.SaveChanges();
            return RedirectToAction("ViewDepartment");
        }

        public IActionResult ViewDepartment()
        {
            var db = new UmsContext();
            var de = db.Departments.ToList();
            return View(de);
        }
    }
}


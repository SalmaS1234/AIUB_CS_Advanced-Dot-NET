﻿using System;
using System.Collections.Generic;

namespace MySqlConnection_db.EF ;

public partial class Course
{
    public string Id { get; set; } = null!;

    public string Name { get; set; } = null!;

    public string CourseCode { get; set; } = null!;

    public string Credit { get; set; } = null!;
}

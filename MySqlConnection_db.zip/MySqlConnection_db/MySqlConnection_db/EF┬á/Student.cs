﻿using System;
using System.Collections.Generic;

namespace MySqlConnection_db.EF ;

public partial class Student
{
    public string Id { get; set; } = null!;

    public string Name { get; set; } = null!;

    public string Cgpa { get; set; } = null!;
}

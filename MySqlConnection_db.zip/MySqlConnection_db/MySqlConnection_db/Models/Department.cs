﻿using System;
using System.ComponentModel.DataAnnotations;
namespace MySqlConnection_db.Models
{
	public class Department
	{
		public string ID { get; set; }
		public string Name { get; set; }
	}
}


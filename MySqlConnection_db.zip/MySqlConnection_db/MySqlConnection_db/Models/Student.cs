﻿using System;
using System.ComponentModel.DataAnnotations;
namespace MySqlConnection_db.Models
{
	public class Student
	{
		[Required]
		public String ID { get; set; }
		[Required]
		public String Name { get; set; }
		[Required]
		public string CGPA { get; set; }
	}
}


﻿using System;
using System.ComponentModel.DataAnnotations;
namespace MySqlConnection_db.Models
{
	public class Course
	{
		[Required]
		public string ID { get; set; }
		[Required]
		public string Name { get; set; }
		[Required]
		public string CourseCode{ get; set; }
		[Required]
		public string Credit { get; set; }
	}
}

